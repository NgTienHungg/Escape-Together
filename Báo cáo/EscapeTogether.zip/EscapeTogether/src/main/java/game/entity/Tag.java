/* Author: NgTienHungg */
package game.entity;

public enum Tag {
    Default,
    BlueCharacter,
    RedCharacter,
    GreenCharacter,
    Box,
    Key,
}
