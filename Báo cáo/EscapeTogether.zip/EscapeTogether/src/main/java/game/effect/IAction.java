/* Author: NgTienHungg */
package game.effect;

public interface IAction {

    void excute();
}
