/* Author: NgTienHungg */
package game.state;

public enum GameStateType {
    Intro,
    Menu,
    Play,
    About,
    Win
}
