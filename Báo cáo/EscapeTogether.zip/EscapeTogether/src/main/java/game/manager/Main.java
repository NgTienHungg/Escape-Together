/* Author: NgTienHungg */
package game.manager;

public class Main {

    public static void main(String[] args) {
        Game.getInstance().run();
    }
}
